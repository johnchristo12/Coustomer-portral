from odoo import fields, models
from datetime import datetime, date
from dateutil.relativedelta import relativedelta


class InventoryAgeingWizard(models.TransientModel):
    _name = "inventory.ageing.wizard"
    _description = "Inventory Ageing"

    period_length = fields.Integer(string='Period Length (Days)', required=True)
    product_ids = fields.Many2many('product.product', string='Product')
    date_from = fields.Date(string='Date', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True)
    warehouse_id = fields.Many2one('stock.warehouse', string='Warehouse', required=True)
    location_id = fields.Many2one('stock.location', string='Location')

    def inventory_ageing_excel(self):
        data = {
            'date': self.date_from,
            'period_length': self.period_length,
            'company_id': self.company_id.id,
            'company_id_name': self.company_id.name,
            'warehouse_id': self.warehouse_id.id,
            'warehouse_id_name': self.warehouse_id.name,
            'location': self.location_id.id,
            'location_name': self.location_id.name,
            'product_id': (self.product_ids.ids),
            'form_data': self.read()
        }
        return self.env.ref('inventory_ageing.inventory_ageing_excel').report_action(self, data=data)
