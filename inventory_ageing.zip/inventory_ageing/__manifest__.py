{
    'name': 'Inventory Ageing',
    'version': '1.0',
    'category': 'Inventory/Delivery',
    'sequence': 10,
    'summary': 'Inventory Ageing',
    'description': """This module provides features to take a excel report of bill-wise aged product quantity.""",
    'website': 'https://www.odoo.com/page/employees',
    'depends': ['report_xlsx'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/inventory_ageing_wizard.xml',
        'views/inventory_ageing.xml',
        'report/report.xml'
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'qweb': [],
    'license': 'LGPL-3',
}
