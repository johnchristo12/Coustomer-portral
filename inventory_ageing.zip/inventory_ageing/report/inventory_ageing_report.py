from odoo import fields, models
from datetime import datetime
from dateutil.relativedelta import relativedelta


class InventoryAgeingXlsx(models.AbstractModel):
    _name = "report.inventory_ageing.inventory_ageing_excel"
    _inherit = "report.report_xlsx.abstract"

    def generate_xlsx_report(self, workbook, data, partners):
        product = tuple(data['product_id'])
        date = data['date']
        period_length = data['period_length']

        periods = {}
        start = datetime.strptime(str(date), '%Y-%m-%d')
        for i in range(5)[::-1]:
            stop = start - relativedelta(days=period_length)
            periods[str(i)] = {
                'name': (i != 0 and (
                        str((5 - (i + 1)) * period_length) + '-' + str((5 - i) * period_length)) or (
                                 '+' + str(4 * period_length))),
                'stop': start.strftime('%Y-%m-%d'),
                'start': (i != 0 and stop.strftime('%Y-%m-%d') or False),
            }
            start = stop - relativedelta(days=1)

        x4 = periods['4']['stop']
        y4 = periods['4']['start']
        x3 = periods['3']['stop']
        y3 = periods['3']['start']
        x2 = periods['2']['stop']
        y2 = periods['2']['start']
        x1 = periods['1']['stop']
        y1 = periods['1']['start']
        x0 = periods['0']['stop']

        sheet = workbook.add_worksheet('STOCK INVENTORY AGEING')
        bold = workbook.add_format({'align': 'left'})
        bold1 = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': '#c7c5c6', 'border': 1})
        size = workbook.add_format({'font_size': 20, 'bg_color': '#c7c5c6', 'align': 'center', 'border': 1})
        rowss = sheet.set_default_row(20)

        row = 10
        col = 0
        sheet.set_column('A:A', 17)
        sheet.set_column('B:B', 30)
        sheet.set_column('C:C', 25)
        sheet.set_column('D:D', 15)
        sheet.set_column('E:E', 15)
        sheet.set_column('F:F', 15)
        sheet.set_column('G:G', 15)
        sheet.set_column('H:H', 15)
        sheet.set_row(1, rowss)

        sheet.merge_range('A10:A11', 'Code', bold1,)
        sheet.merge_range('B10:B11', 'Product Name', bold1)
        sheet.merge_range('C10:C11', 'Total Quantity', bold1)
        sheet.write(row, col + 3, 'Quantity', bold1)
        sheet.write(row - 1, col + 3, periods['4']['name'], bold1)
        sheet.write(row, col + 4, 'Quantity', bold1)
        sheet.write(row - 1, col + 4, periods['3']['name'], bold1)
        sheet.write(row, col + 5, 'Quantity', bold1)
        sheet.write(row - 1, col + 5, periods['2']['name'], bold1)
        sheet.write(row, col + 6, 'Quantity', bold1)
        sheet.write(row - 1, col + 6, periods['1']['name'], bold1)
        sheet.write(row, col + 7, 'Quantity', bold1)
        sheet.write(row - 1, col + 7, periods['0']['name'], bold1)
        sheet.merge_range('C1:E1', 'Stock Ageing', size)

        sheet.write(row - 8, col + 1, 'Date', bold1)
        sheet.write(row - 8, col + 2, data['date'], bold)
        sheet.write(row - 7, col + 1, 'Company', bold1)
        sheet.write(row - 7, col + 2, data['company_id_name'], bold)
        sheet.write(row - 6, col + 1, 'Warehouse', bold1)
        sheet.write(row - 6, col + 2, data['warehouse_id_name'], bold)
        sheet.write(row - 5, col + 1, 'Period Length', bold1)
        sheet.write(row - 5, col + 2, data['period_length'], bold)

        if (data['location'] != False and product != () and len(product) != 1):
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                    case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                    case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                    from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                    left join product_template on product_product.product_tmpl_id = product_template.id
                                    left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                    where stock_quant.company_id = '%s' and stock_quant.location_id = '%s' and stock_warehouse.id = '%s'
                                    and (stock_quant.product_id in %s) """)
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'], data['location'],
                                   data['warehouse_id'], product))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])

        elif (data['location'] != False and product == ()):
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                                    case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                                    Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                                    case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                                    from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                                    left join product_template on product_product.product_tmpl_id = product_template.id
                                                    left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                                    where stock_quant.company_id = '%s' and stock_quant.location_id = '%s' and stock_warehouse.id = '%s'""")
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'], data['location'],
                                   data['warehouse_id']))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])

        elif (data['location'] == False and product != () and len(product) != 1):
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                                       case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                                       case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                                       from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                                       left join product_template on product_product.product_tmpl_id = product_template.id
                                                       left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                                       where stock_quant.company_id = '%s' and stock_warehouse.id = '%s' and stock_quant.product_id in %s""")
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'], data['warehouse_id'],
                                   product))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])

        elif (data['location'] != False and len(product) == 1):
            product_id = data['product_id'][0]
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                                case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                                case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                                from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                                left join product_template on product_product.product_tmpl_id = product_template.id
                                                left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                                where stock_quant.company_id = '%s' and stock_quant.location_id = '%s' and stock_warehouse.id = '%s'
                                                and (stock_quant.product_id = '%s') """)
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'], data['location'],
                                   data['warehouse_id'], product_id))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])

        elif (data['location'] == False and len(product) == 1):
            product_id = data['product_id'][0]
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                                case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                                Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                                case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                                from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                                left join product_template on product_product.product_tmpl_id = product_template.id
                                                left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                                where stock_quant.company_id = '%s' and stock_warehouse.id = '%s' and stock_quant.product_id = '%s' """)
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'],
                                   data['warehouse_id'], product_id))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])

        else:
            self.env.cr.execute(("""select product_product.default_code,product_template.name,quantity,
                                                                       case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity Else 0 END As Quantity1,
                                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity2,
                                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity3,
                                                                       Case when stock_quant.create_date BETWEEN '%s' AND '%s' then quantity else 0 end as Quantity4,
                                                                       case when stock_quant.create_date <= '%s' then quantity Else 0 END As Quantity5
                                                                       from stock_quant left join product_product on stock_quant.product_id = product_product.id
                                                                       left join product_template on product_product.product_tmpl_id = product_template.id
                                                                       left join stock_warehouse on stock_warehouse.company_id = stock_quant.company_id
                                                                       where stock_quant.company_id = '%s' and stock_warehouse.id = '%s'""")
                                % (y4, x4, y3, x3, y2, x2, y1, x1, x0, data['company_id'], data['warehouse_id']))
            move_ids = self.env.cr.dictfetchall()
            for inv in move_ids:
                row += 1
                sheet.write(row, col, inv['default_code'])
                sheet.write(row, col + 1, inv['name'])
                sheet.write(row, col + 2, inv['quantity'])
                sheet.write(row, col + 3, inv['quantity1'])
                sheet.write(row, col + 4, inv['quantity2'])
                sheet.write(row, col + 5, inv['quantity3'])
                sheet.write(row, col + 6, inv['quantity4'])
                sheet.write(row, col + 7, inv['quantity5'])
