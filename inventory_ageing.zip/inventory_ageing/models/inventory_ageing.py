from odoo import fields, models, api


class InventoryAgeing(models.Model):
    _name = "inventory.ageing"
    _description = "Stock Ageing"